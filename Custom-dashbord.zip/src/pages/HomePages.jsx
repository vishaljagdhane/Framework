import React from 'react'

export default function HomePages() {
  return (
    <>
      <h1>Testing</h1>
    </>
  )
}

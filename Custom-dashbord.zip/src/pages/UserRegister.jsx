import { Box, TextField, Typography } from '@mui/material'
import React from 'react'

export default function UserRegister() {
    return (
        <>
            <Box sx={{ background: '#EFF3F8', width: '100%', height: 'auto', position: 'relative', }}>
          <Box sx={{ width: '80%', height: '100vh', bgcolor: '#fff', m: '0px auto', borderRadius: 1,display:'block' }}>
          <Box sx={{padding:2,width:'100%'}}>
          <Typography variant="h3" sx={{textAlign:'center',color:'gray' }}>User Registration</Typography>
    
          </Box>
          <Box>
          <h1>Testing...</h1>
          </Box>
          </Box>


            </Box>
        </>
    )
}

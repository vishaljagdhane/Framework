import { Box } from '@mui/material'
import React from 'react'

export default function TestingApplication() {
  return (
    <>
    <Box sx={{width:'100%',height:'200vh'}}>
    <h1>Tjis Testing Compoanent</h1>
    </Box>
    </>
  )
}
